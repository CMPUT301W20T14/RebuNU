package com.example.rebunu;

public class Rider {
    private Request fetchRequest;

    public void CreateRequest(){
        return createRequest;
    }

    public Request FetchRequest(){
        return fetchRequest;
    }

    public void cancelRequest(){
        return cancelRequest;
    }

    public void confirmRequest(){
        return confirmRequest;
    }
}
